
INSERT INTO address (id, address_line1, address_line2, city, postal_code)
VALUES 
    (1, 'xx', 'yy', 'miasto', '62-030'),
    (2, 'ul. Poselska 14', '25', 'Wrocław', '53-020'),
    (3, 'Krótka 12', '1', 'Warszawa', '00-013'),
    (4, 'ul. Nowa 5', '', 'Kraków', '30-010'),
    (5, 'Słoneczna 7', '2B', 'Gdańsk', '80-001'),
    (6, 'Wiejska 10', '12', 'Poznań', '60-005'),
    (7, 'ul. Żeromskiego 3', '', 'Łódź', '90-030'),
    (8, 'Długa 18', '', 'Szczecin', '70-011'),
    (9, 'Narutowicza 22', '', 'Katowice', '40-003'),
    (10, 'ul. Wojska Polskiego 9', '5A', 'Kraków', '30-015');

INSERT INTO doctor (id, doctor_number, email, first_name, last_name, specialization, telephone_number)
VALUES 
    (1, 'LEK001', 'lek1@gmail.com', 'Jan', 'Kowalski', 'Kardiologia', '123-456-789'),
    (2, 'LEK002', 'lek2@gmail.com', 'Anna', 'Nowak', 'Pediatria', '987-654-321'),
    (3, 'LEK003', 'lek3@gmail.com', 'Piotr', 'Wiśniewski', 'Ortopedia', '111-222-333'),
    (4, 'LEK004', 'lek4@gmail.com', 'Maria', 'Dąbrowska', 'Dermatologia', '444-555-666'),
    (5, 'LEK005', 'lek5@gmail.com', 'Tomasz', 'Lewandowski', 'Neurologia', '777-888-999');

INSERT INTO medical_treatment (id, description, type)
VALUES
    (1, 'Badanie krwi', 'Laboratoryjne'),
    (2, 'Konsultacja lekarska', 'Konsultacja'),
    (3, 'USG jamy brzusznej', 'Diagnostyczne'),
    (4, 'Recepta na leki', 'Farmakologiczne'),
    (5, 'Zabieg fizjoterapeutyczny', 'Fizjoterapia');

INSERT INTO patient (id, date_of_birth, email, first_name, last_name, last_visit_date, patient_number, telephone_number)
VALUES
    (1, '1990-05-15', 'lukasz.grzesiak@example.com', 'Łukasz', 'Grzesiak', '2024-05-06', 'PAT001', '123-456-789'),
    (2, '1985-08-20', 'witold.gombrowicz@example.com', 'Witold', 'Gombrowicz','2024-05-07', 'PAT002', '987-654-321'),
    (3, '1978-12-10', 'robert.lewandowski@example.com', 'Robert', 'Lewandowski','2024-05-08', 'PAT003', '111-222-333'),
    (4, '1995-03-25', 'maria.karas@example.com', 'Maria', 'Karaś','2024-05-09', 'PAT004', '444-555-666'),
    (5, '1980-07-18', 'izabela.rudzka@example.com', 'Izabela', 'Rudzka','2024-05-16', 'PAT005', '777-888-999'),
    (6, '1992-06-30', 'magdalena.kaczmarek@example.com', 'Magdalena', 'Kaczmarek','2024-05-26', 'PAT006', '222-333-444'),
    (7, '1987-09-12', 'michał.wójcik@example.com', 'Michał', 'Wójcik','2024-05-13', 'PAT007', '555-666-777'),
    (8, '1976-04-05', 'barbara.zajac@example.com', 'Barbara', 'Zając','2024-05-02', 'PAT008', '888-999-000'),
    (9, '1998-11-08', 'andrzej.krawczyk@example.com', 'Andrzej', 'Krawczyk','2024-04-06', 'PAT009', '333-444-555'),
    (10, '1973-02-14', 'ewa.szewczyk@example.com', 'Ewa', 'Szewczyk','2024-03-06', 'PAT010', '999-000-111'),
    (11, '1991-10-22', 'marek.adamczyk@example.com', 'Marek', 'Adamczyk','2024-05-22', 'PAT011', '444-555-666'),
    (12, '1983-01-19', 'justyna.nowakowska@example.com', 'Justyna', 'Nowakowska','2024-05-21', 'PAT012', '000-111-222'),
    (13, '1979-08-07', 'krzysztof.wieczorek@example.com', 'Krzysztof', 'Wieczorek','2024-05-18', 'PAT013', '111-222-333'),
    (14, '1996-12-03', 'agata.jakubowska@example.com', 'Agata', 'Jakubowska','2024-05-11', 'PAT014', '222-333-444'),
    (15, '1988-05-28', 'pawel.mazurek@example.com', 'Paweł', 'Mazurek','2024-05-01', 'PAT015', '333-444-555'),
    (16, '1975-07-16', 'natalia.adamczyk@example.com', 'Natalia', 'Adamczyk','2024-01-06', 'PAT016', '444-555-666'),
    (17, '1993-09-11', 'wojciech.wiśniewski@example.com', 'Wojciech', 'Wiśniewski','2024-05-01', 'PAT017', '555-666-777'),
    (18, '1981-11-24', 'katarzyna.kowalczyk@example.com', 'Katarzyna', 'Kowalczyk','2024-06-01', 'PAT018', '666-777-888'),
    (19, '1997-02-18', 'maciej.kamiński@example.com', 'Maciej', 'Kamiński','2024-05-20', 'PAT019', '777-888-999'),
    (20, '1974-04-09', 'jolanta.woźniak@example.com', 'Jolanta', 'Woźniak','2024-05-19', 'PAT020', '888-999-000');

INSERT INTO visit (id, description, time, doctor_id, patient_id)
VALUES
    (1, 'Wizyta kontrolna', '2024-05-06 15:00:00', 1, 1),
    (2, 'Badanie podstawowe', '2024-05-06 10:30:00', 2, 2),
    (3, 'Wizyta specjalistyczna', '2024-05-06 14:45:00', 3, 3),
    (4, 'Konsultacja lekarska', '2024-05-06 11:15:00', 4, 4),
    (5, 'Zabieg medyczny', '2024-05-06 13:00:00', 5, 5),
    (6, 'Wizyta kontrolna', '2024-05-13 15:00:00', 5, 5);

INSERT INTO doctor_address (doctor_id, address_id)
VALUES
    (1, 1),
    (2, 2);

 INSERT INTO patient_address (patient_id, address_id)
 VALUES
    (1, 1),
    (2, 2);

--Przykładowe zapytania do Lab3 w SQL
--1. SELECT * FROM PATIENT WHERE LAST_NAME = "Mazurek"
--2. SELECT * FROM VISIT WHERE PATIENT_ID = 2
--3. SELECT P.ID, P.FIRST_NAME, P.LAST_NAME FROM VISIT V
-- LEFT OUTER JOIN PATIENT P ON P.ID = V.PATIENT_ID
-- GROUP BY P.ID
-- HAVING COUNT(P.ID) >= 2 ##(X = 2)
--4.
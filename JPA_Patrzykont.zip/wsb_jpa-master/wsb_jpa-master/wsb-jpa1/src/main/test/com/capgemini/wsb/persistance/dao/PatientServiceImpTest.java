package com.capgemini.wsb.persistance.dao;

import com.capgemini.wsb.dto.PatientTO;
import com.capgemini.wsb.dto.VisitTO;
import com.capgemini.wsb.persistence.entity.PatientEntity;
import com.capgemini.wsb.service.PatientService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PatientServiceImpTest {

    @Autowired
    private PatientService patientService;

    @Transactional
    @Test
    public void testShouldFindPatientById() {
        // given
        long patientId = 1L;

        // when
        PatientTO patientEntity = patientService.findByID(patientId);

        // then
        assertThat(patientEntity).isNotNull();
        List<VisitTO> visits = patientEntity.getVisits();
        assertThat(visits).isNotEmpty();
        assertThat(visits.get(0).getPatientId(1L)).isEqualTo(patientId);
    }

    @Test
    public void testShouldSavePatient() {
        // given
        PatientEntity patientEntity = new PatientEntity();
        patientEntity.setFirstName("Jan");
        patientEntity.setLastName("Kowalski");
        patientEntity.setTelephoneNumber("123412351");

        // when
        final PatientEntity saved = patientService.save(patientEntity);

        // then
        assertThat(saved).isNotNull();
        assertThat(saved.getId()).isNotNull();
    }

    @Test
    public void testShouldDeletePatient() {
        // given
        PatientEntity patientEntity = new PatientEntity();
        patientEntity.setFirstName("Adam");
        patientEntity.setLastName("Nowak");
        patientEntity.setTelephoneNumber("333666999");

        final PatientEntity saved = patientService.save(patientEntity);
        Long patientId = saved.getId();

        // when
        patientService.delete(patientId);

        // then
        final PatientTO removed = patientService.findByID(patientId);
        assertThat(removed).isNull();
    }

}

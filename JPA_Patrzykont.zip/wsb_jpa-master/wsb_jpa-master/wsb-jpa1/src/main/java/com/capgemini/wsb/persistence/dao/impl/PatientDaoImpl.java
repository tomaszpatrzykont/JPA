package com.capgemini.wsb.persistence.dao.impl;

import com.capgemini.wsb.persistence.dao.PatientDao;
import com.capgemini.wsb.persistence.entity.PatientEntity;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class PatientDaoImpl extends AbstractDao<PatientEntity, Long> implements PatientDao {
    @Override
    public List<PatientEntity> findBylastName(String plastName) {
        return entityManager.createQuery("select patient from PatientEntity patient " +
                        "where patient.lastName like :param1", PatientEntity.class)
                .setParameter("param1", plastName)
                .getResultList();
    }


    @Override
    public List<PatientEntity> findPatientWithMoreThanCountOfVisits(long pVisits) {
        return entityManager.createQuery("SELECT p from PatientEntity p " +
                        "JOIN p.visits v " +
                        "GROUP BY p.id " +
                        "HAVING COUNT(v) > :countofVisits", PatientEntity.class)
                .setParameter("countofVisits", pVisits)
                .getResultList();
    }

    @Override
    public List<PatientEntity> findVisitsByPatientID(long pId) {
        return entityManager.createQuery(
                        "SELECT p FROM PatientEntity p JOIN p.visits v WHERE v.patient_id = :patientId",
                        PatientEntity.class)
                .setParameter("patientId", pId)
                .getResultList();
    }
}




package com.capgemini.wsb.dto;

import java.time.LocalDateTime;
import java.util.function.IntPredicate;

public class VisitTO {

    private Long id;

    private LocalDateTime visitDateTime;

    private String description;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getVisitDateTime() {
        return visitDateTime;
    }

    public void setVisitDateTime(LocalDateTime visitDateTime) {
        this.visitDateTime = visitDateTime;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public IntPredicate getPatientId(Long id) {
    this.id = id;
        return null;
    }
}

package com.capgemini.wsb.service;

import com.capgemini.wsb.dto.PatientTO;
import com.capgemini.wsb.persistence.entity.PatientEntity;

public interface PatientService {
    public PatientTO findByID(final Long id);

    PatientEntity findOne(long id);

    Byte count();

    PatientEntity save(PatientEntity patientEntity);

    void delete(Long id);
}
    // static PatientEntity findByID(final long idl) {
  //  }

  //  public PatientTO findById(final Long id);
    //static PatientEntity findOne(long l) {
    //    return null;



